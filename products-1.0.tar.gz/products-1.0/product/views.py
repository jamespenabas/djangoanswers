from django.http.response import HttpResponse
from django.views import View
from django.views.generic import CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import UserForm
import secrets
from django.core.mail import send_mail
from .models import UserData
from django.urls import reverse_lazy


class WelcomeView(LoginRequiredMixin, View):
	def get(self, request):
		user = self.request.user
		return HttpResponse("We sent a verification link to your email! ")


class SignupView(CreateView):
	form_class = UserForm
	template_name = "product/signup.html"
	context_object_name = "form"
	success_url = reverse_lazy("product:welcome")
	
	def form_valid(self, form):
		token = secrets.token_urlsafe()
		link = "http://127.0.0.1:8000/profile/{}".format(token)
		form.instance.token = token
		email = self.request.POST["email"]
		send_mail("VERIFICATION", "%s"%link,None, [email])
		return  super().form_valid(form)
		


class ProfileCreateView(View):
	def get(self, request, token):
		try:
			dat = UserData.objects.get(token=token)
		except UserData.DoesNotExist:
			return HttpResponse("Invalid link")
		else:
			return HttpResponse("Verified")
	