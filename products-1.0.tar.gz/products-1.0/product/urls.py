from .views import WelcomeView
from django.urls import path
from .views import SignupView, ProfileCreateView

app_name = "product"
urlpatterns = [
path("", WelcomeView.as_view(), name="welcome"),
path("signup/", SignupView.as_view()),
path("profile/<str:token>/", ProfileCreateView.as_view())]
