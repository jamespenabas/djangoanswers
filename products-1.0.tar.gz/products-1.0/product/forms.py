from .models import UserData
from django import forms


class UserForm(forms.ModelForm):
	class Meta:
		model = UserData
		fields = ("email", )
		