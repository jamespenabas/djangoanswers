from django.db import models
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.core.exceptions import ValidationError

# Create your models here.
class Intel(models.Model):
    agent = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    info = models.TextField(max_length=1000)

    class Meta:
        verbose_name = "intel"
        verbose_name_plural = "intels"

    def __str__(self):
        return self.info[:40] + "..."


class Product(models.Model):
    name = models.CharField(max_length=100, unique=True)
    price = models.PositiveIntegerField()
    date_added = models.DateTimeField(auto_now=True)
    expiry_date = models.DateTimeField()
    quantity = models.PositiveIntegerField()
    expired = models.BooleanField(default=False)
    CATEGORIES = (
        ("men_fashion", "Men Fashion"),
        ("ladies_fashion", "Ladies Fashion"),
        ("smartphone", "Smartphone"),
        ("comp", "Computers"),
    )
    category = models.CharField(max_length=100, choices=CATEGORIES)

    class Meta:
        verbose_name = _("product")
        verbose_name_plural = _("products")
        ordering = ("date_added",)

    def __str__(self):
        return self.name

    def isExpired(self):
        return timezone.now() > self.expiry_date

    def clean(self, *args, **kwargs):
        if self.expired:
            raise ValidationError({"expired": _("Product expired")})
        if self.isExpired():
        	raise ValidationError({"expiry_date": _("Invalid Expiry date")})
        	

class UserData(models.Model):
	email = models.EmailField(max_length=200)
	token = models.CharField(max_length=100)
	