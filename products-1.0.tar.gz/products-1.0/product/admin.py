from django.contrib import admin
from .models import Product
from django.contrib.admin import ModelAdmin
from django.utils import timezone
# Register your models here.

@admin.action(description="Mark as expired")
def expired(modeladmin, request, queryset):
	queryset.update(expired=True)
	with open("mod.txt", "w") as file:
		file.write("{}".format(request.user))

@admin.action(description="Delete expired product")
def delete_expired(modeladmin, request, queryset):
	for obj in queryset:
		if obj.expiry_date < timezone.now():
			obj.delete()

@admin.action(description="Check expiry date")
def check_expiry(modeladmin, request, queryset):
	for obj in queryset:
		if obj.expiry_date < timezone.now():
			obj.expired = True
			obj.save(update_fields=["expired"])
			
			
class IntelAdmin(ModelAdmin):
	list_display = ("name", "price", "isExpired")
	actions = [check_expiry, delete_expired]
	
	@admin.display(description="Expired", boolean=True)
	def isExpired(self, obj):
		return obj.expiry_date < timezone.now()
admin.site.register(Product, IntelAdmin)
