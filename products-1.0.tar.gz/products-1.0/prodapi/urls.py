from .views import ProductAPIView, UserCreateAPI, LoginView
from django.urls import path

app_name = "prodapi"

urlpatterns = [
path("products/", ProductAPIView.as_view()),
path("signup/", UserCreateAPI.as_view()),
path("login/", LoginView.as_view())
]