from rest_framework import generics
from rest_framework.views import APIView
from product.models import Product
from .serializers import (
ProductSerializer, UserSerializer)
from django.contrib.auth import authenticate
from rest_framework.response import Response
from rest_framework import status
from django.core.exceptions import ValidationError


class ProductAPIView(generics.ListCreateAPIView):
	queryset = Product.objects.all()
	serializer_class = ProductSerializer

	
class UserCreateAPI(generics.CreateAPIView):
	permission_classes = ()
	authentication_classes = ()
	serializer_class = UserSerializer


class LoginView(APIView):
	permission_classes = ()
	
	def post(self, request):
		uname = request.data.get("username")
		
		pwd = request.data.get("password")
		user = authenticate(username=uname, password=pwd)
		if user:
			return Response({"token": user.auth_token.key})
		return Response({"error": "Invalid username or password"}, status=status.HTTP_400_BAD_REQUEST)
	
			