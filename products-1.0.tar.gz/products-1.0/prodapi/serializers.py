from rest_framework.serializers import ModelSerializer
from product.models import Product
from django.contrib.auth import get_user_model
from rest_framework.authtoken.models import Token
from django.core.exceptions import ValidationError


class ProductSerializer(ModelSerializer):
	class Meta:
		model = Product
		fields = "__all__"

class UserSerializer(ModelSerializer):
	
	class Meta:
		model = get_user_model()
		fields = ["username", "email", "password"]
		extra_kwargs = {"password": {"write_only": True}}
	
	def create(self, validated_data):
		
		user_model = get_user_model()
		
		user = user_model(
		username=validated_data["username"],
		email=validated_data["email"])
	
		
		user.set_password(validated_data["password"])
		user.save()
		Token.objects.create(user=user)
		return user
